//
//  ReviewPageViewController.h
//  GMAT
//
//  Created by Do Ngoc Trinh on 5/13/16.
//  Copyright © 2016 Trung Đức. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReviewPageViewController : UIPageViewController

@end
