//
//  SummaryVC.m
//  EZ GMAT
//
//  Created by Do Ngoc Trinh on 6/9/16.
//  Copyright © 2016 Do Ngoc Trinh. All rights reserved.
//

#import "SummaryVC.h"
#import "SummaryCell.h"
#import "MagicalRecord.h"
#import "QuestionType.h"
#import "Question.h"
#import "StudentAnswer.h"
@interface SummaryVC ()
{
    NSArray *listTypes;
    NSArray *questions;
}
@end

@implementation SummaryVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self configView];
    
    [self countTag];
    [self progressForEachSubtype];
    
    listTypes = [QuestionType MR_findAll];
    questions = [Question MR_findAll];
    //_lblUntag.text = [NSString stringWithFormat:@"% ld",(unsigned long)listTypes.count];

    [_tbvCategories reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)configView;{
    [self progressViewShow];
    _viewTag.backgroundColor = [kAppColor colorWithAlphaComponent:0.5];
    _tbvCategories.backgroundColor = [_viewTag.backgroundColor colorWithAlphaComponent:0.2];
}

#pragma mark - TableView Datasource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView;{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;{
    return listTypes.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString *cellID =[NSString stringWithFormat:@"%@",[SummaryCell class]];
    
    SummaryCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        NSArray *nib = [[NSBundle mainBundle]loadNibNamed:cellID owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    QuestionType *selectedType = listTypes[indexPath.row];
    cell.textLabel.text = selectedType.detail;
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 80;
}
#pragma mark - TableView Delegate
#pragma mark - tag counter
-(void)countTag;{
    NSPredicate *querry = [NSPredicate predicateWithFormat:@"self.tag = %@", [NSNumber numberWithInteger:-1]];
    NSArray *questionUntag = [Question MR_findAllWithPredicate:querry];
    _lblUntag.text = [NSString stringWithFormat:@" %d", questionUntag.count];
    
    querry = [NSPredicate predicateWithFormat:@"self.tag = %@", [NSNumber numberWithInteger:0]];
    questionUntag = [Question MR_findAllWithPredicate:querry];
    _lblStar.text = [NSString stringWithFormat:@" %d", questionUntag.count];
    
    
    querry = [NSPredicate predicateWithFormat:@"self.tag = %@", [NSNumber numberWithInteger:1]];
    questionUntag = [Question MR_findAllWithPredicate:querry];
    _lblRed.text = [NSString stringWithFormat:@" %d", questionUntag.count];
    
    
    querry = [NSPredicate predicateWithFormat:@"self.tag = %@", [NSNumber numberWithInteger:2]];
    questionUntag = [Question MR_findAllWithPredicate:querry];
    _lblGreen.text = [NSString stringWithFormat:@" %d", questionUntag.count];
    
    querry = [NSPredicate predicateWithFormat:@"self.tag = %@", [NSNumber numberWithInteger:3]];
    questionUntag = [Question MR_findAllWithPredicate:querry];
    _lblYellow.text = [NSString stringWithFormat:@" %d", questionUntag.count];
    
    querry = [NSPredicate predicateWithFormat:@"self.tag = %@", [NSNumber numberWithInteger:4]];
    questionUntag = [Question MR_findAllWithPredicate:querry];
    _lblAverageTime.text = [NSString stringWithFormat:@" %lu", (unsigned long)questionUntag.count];
}
#pragma mark - Progress View
-(void)progressViewShow;{
    self.viewProgress.textStyle               = MCPercentageDoughnutViewTextStyleUserDefined;
    self.viewProgress.linePercentage          = 0.1;
    self.viewProgress.animationDuration       = 0.5;
    self.viewProgress.showTextLabel           = YES;
    self.viewProgress.animatesBegining        = YES;
    self.viewProgress.textLabel.textColor     = kColor_NavigationBarBackground;
    self.viewProgress.fillColor               = kColor_NavigationBarBackground;
    self.viewProgress.unfillColor             = [UIColor colorWithRed:255.0/255 green:183.0/255 blue:83.0/255 alpha:1.0];
    self.viewProgress.textLabel.font          = [UIFont systemFontOfSize:1.0];
    [self.viewProgress setInitialPercentage:0.5f];
    
    //count
    
    NSPredicate *pre = [NSPredicate predicateWithFormat:@"result = %@", [NSNumber numberWithInt:1]];
    NSArray *trueAnswer = [StudentAnswer MR_findAllWithPredicate:pre];
    NSArray *totalQuestions = [Question MR_findAll];
   // NSLog(@"student answer count %lu", [StudentAnswer MR_findAll].count);
    [self.viewProgress setPercentage:(float)trueAnswer.count/totalQuestions.count];
    self.viewProgress.textLabel.text          = [NSString stringWithFormat:@" %.lf%% ", self.viewProgress.percentage*100];
}
-(void) progressForEachSubtype;{
    NSPredicate *pre =  [NSPredicate predicateWithFormat:@"(result = %@)AND(question.type = 'RC')", [NSNumber numberWithInt:1]];
    
    NSInteger trueAswer = [StudentAnswer MR_countOfEntitiesWithPredicate:pre];
    NSLog(@"Count for subtype : %ld", trueAswer);
    
}

@end
