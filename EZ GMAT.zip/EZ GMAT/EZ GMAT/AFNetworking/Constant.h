//
//  Constant.h
//  DemoExploreCategories
//
//  Created by Trung Đức on 3/5/16.
//  Copyright © 2016 Trung Đức. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Constant : NSObject

#define kSoundCloudExploreURL               @"https://api-v2.soundcloud.com/explore/%@?client_id=02gUJC0hH2ct1EGOcYXQIzRFU91c72Ea"

@end
