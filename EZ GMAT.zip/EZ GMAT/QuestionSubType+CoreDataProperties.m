//
//  QuestionSubType+CoreDataProperties.m
//  EZ GMAT
//
//  Created by Do Ngoc Trinh on 6/9/16.
//  Copyright © 2016 Do Ngoc Trinh. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "QuestionSubType+CoreDataProperties.h"

@implementation QuestionSubType (CoreDataProperties)

@dynamic code;
@dynamic detail;
@dynamic questionType;

@end
